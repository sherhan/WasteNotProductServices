# Convenience file to match gem name
require 'hmac'
